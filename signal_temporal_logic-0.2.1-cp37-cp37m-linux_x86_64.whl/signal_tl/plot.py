""" This module provides utility functions to plot trace/robustness using matplotlib.

"""

import numpy as np
import matplotlib.pyplot as plt

from . import compute_robustness

def plot_signal(signal, label=None):
    """ Plot signal using matplotlib.

    Args:
        signal (Siignal): target signal
        label (str): label of the signal to display
    """
    plt.plot(signal.times, signal.values, label=label)

def plot_negative_span(signal, facecolor='red', alpha=0.3):
    """ Fill with a rectangle the span in which the value of signal is negative.

    Args:
        signal (Signal): target signal
        facecolor (str): color of rectangle
    """
    times = np.array(signal.times)
    neg = np.array(signal.values) < 0
    starts = ~neg[:-1] & neg[1:]
    ends = neg[:-1] & ~neg[1:]
    for start, end in zip(times[:-1][starts], times[1:][ends]):
        plt.axvspan(start, end, facecolor=facecolor, alpha=alpha)

def plot_robustness(phi, trace, **figure_args):
    """ Plot the robustness with its formula displayed.

    Args:
        phi (ast): STL formula
        trace (trace): trace to be evaluated
    """
    plot_signal(compute_robustness(phi, trace), label=str(phi), **figure_args)

def plot_trace(trace, title=None, sharey=True, **figure_args):
    """ Plot all of the signals in the trace

    Args:
        trace (trace): trace
        title (str): title of the resulting figure
        sharey (bool): share Y axis
    """
    fig, ax = plt.subplots(len(trace), sharex=True, sharey=sharey, **figure_args)
    for i, (name, signal) in enumerate(trace.items()):
        ax[i].plot(signal.times, signal.values)
        ax[i].set_title(name)
    if title:
        fig.suptitle(title, color='red')
    fig.tight_layout()
