from __future__ import annotations

import functools

from typing import List, Union, Dict, Any, Callable, Tuple
import inspect
from copy import deepcopy
from signal_tl._cext.signal import Signal


class Context:
    def __init__(self):
        self._dict: Dict[str, Tuple[List[str], Any]] = {}

    def update(self, symbol: str, *, args: List[str], entity: Any) -> None:
        self._dict.update({symbol: (args, entity)})

    def resolve(self, symbol: str) -> Tuple[List[str], Any]:
        """Resolves a symbol to an entity.
        Returns a tuple of a list of arguments and the entity.
        """
        try:
            return self._dict[symbol]
        except KeyError as e:
            raise KeyError(f"Symbol {symbol} not found in context.") from e

class Node:
    pass

class Proposition(Node):
    """Base class for all proposition nodes in the AST."""
    _prop_names: List[str]
    children: List[Proposition]
    has_math_nodes: bool = False

    def __init__(self, *children, **kwargs) -> None:
        if not hasattr(self, "_prop_names"):
            raise RuntimeError("Proposition class must be instantiated via its subclass that defines `_prop_names`.")
        for key, value in kwargs.items():
            if (key == "lhs" or key == "rhs") and not isinstance(value, MathExpression):
                # Implicit conversion
                value = MathExpression.from_raw(value)
            setattr(self, key, value)
        self.children = children

        if not all(isinstance(child, Proposition) for child in self.children):
            raise TypeError("All children must be propositions.")

    def __repr__(self) -> str:
        props = [f"{prop}={getattr(self, prop, None)}" for prop in self._prop_names if prop != "children"]
        if len(self.children) > 0:
            props.append(f"children={list(self.children)}")
        return f"{self.__class__.__name__}({','.join(props)})"

    def to_evaluation_tree(self):
        """Builds an evaluation tree from the AST."""
        raise NotImplementedError()

    @property
    def predicate_call_nodes(self):
        """Returns a list of all predicate-call nodes in the tree.
        Useful for enumerating all predicates required for the evaluation of tree."""
        nodes = []
        if self.__class__.__name__ == "PredicateCall":
            nodes.append(self)
        for child in self.children:
            nodes.extend(child.predicate_call_nodes)
        return nodes

    @property
    def math_nodes(self):
        """Returns a list of all non-constant math nodes in the tree.
        Useful for enumerating all maths required for the evaluation of tree.
        Currently very ad-hoc, only detects a node as math if it has props `lhs` and `rhs`."""
        nodes = []
        if self.has_math_nodes:
            if isinstance(self.lhs, MathExpression) and \
                isinstance(self.rhs, MathExpression):
                if self.lhs.is_constant and self.rhs.is_constant:
                    pass # ignore constant nodes
                elif self.lhs.is_constant:
                    nodes.append(self.rhs)
                elif self.rhs.is_constant:
                    nodes.append(self.lhs)
                else:
                    nodes.append(self.lhs - self.rhs)

        for child in self.children:
            nodes.extend(child.math_nodes)
        return nodes

    def substitute_variables(self, assignments: Dict[str, MathExpression]) -> Proposition:
        """Substitutes variables in the tree with the given assignments.
        This method may modify the tree in-place, call deepcopy if you want to preserve the original tree."""
        if len(self.children) == 0:
            if not self.has_math_nodes:
                return self
            else:
                self.lhs = self.lhs.substitute_variables(assignments)
                self.rhs = self.rhs.substitute_variables(assignments)
                return self
        else:
            self.children = [child.substitute_variables(assignments) for child in self.children]
            return self

class MathExpression(Node):
    """Represents a mathematical expression in the STL formula.
    Only supposed to appear in the atomic propositions like `x > y + 3`."""

    evaluator: Callable[[Dict[str, Any]], Any]
    """A function that takes a variable assignment and returns the evaluated result of the expression.

    Example:
        >>> expr = MathExpression("x + y", lambda trace: trace["x"] + trace["y"])
        >>> expr.evaluator({"x": 1, "y": 2}) # 3
    """

    def __init__(self, expr: Union[str, float], evaluator) -> None:
        self.expr = expr
        if isinstance(expr, float):
            self.is_constant = True
            self.value = expr
        else:
            self.is_constant = False
        self.evaluator = evaluator

    @classmethod
    def from_raw(cls, value: Union[str, float]):
        if isinstance(value, float) or isinstance(value, int):
            return MathExpression(
                float(value), lambda _: value
            )
        elif isinstance(value, str):
            return MathExpression(
                value, lambda trace: trace.get(value, cls.from_raw(value))
            )

    @classmethod
    def from_function_application(
        cls,
        symbol: str,
        inputs: List[MathExpression],
        context: Context
    ):
        def _call(trace):
            args, entity = context.resolve(symbol)
            assignments = dict(zip(args, inputs))
            new_expr = entity.substitute_variables(assignments)

            return new_expr.evaluator(trace)

        return MathExpression(
            f"{symbol}({', '.join(map(str, inputs))})",
            _call
        )

    def substitute_variables(self, assignments: Dict[str, MathExpression]):
        if self.is_constant:
            return self
        result = self.evaluator(assignments)
        if isinstance(result, float):
            return MathExpression.from_raw(result)
        return result

    def to_key(self):
        """Returns a string representation of the expression, which can be used as a key in a dictionary."""
        return str(self.expr)

    def parend_expr(self):
        if " " in str(self.expr):
            return f"({self.expr})"
        return str(self.expr)

    def __repr__(self) -> str:
        return self.to_key()

    def __neg__(self):
        if self.is_constant:
            return MathExpression(-self.value, lambda trace: -self.evaluator(trace))
        else:
            return MathExpression(f"-{self.parend_expr()}", lambda trace: 0 - self.evaluator(trace))

    def __add__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{self.expr} + {other.expr}",
            lambda trace: self.evaluator(trace) + other.evaluator(trace)
        )

    def __sub__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{self.expr} - {other.parend_expr()}",
            lambda trace: self.evaluator(trace) - other.evaluator(trace)
        )

    def __mul__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{self.parend_expr()} * {other.parend_expr()}",
            lambda trace: self.evaluator(trace) * other.evaluator(trace)
        )

    def __truediv__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{self.parend_expr()} / {other.parend_expr()}",
            lambda trace: self.evaluator(trace) / other.evaluator(trace)
        )

    def __radd__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{other.expr} + {self.expr}",
            lambda trace: other.evaluator(trace) + self.evaluator(trace)
        )

    def __rsub__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{other.expr} - {self.parend_expr()}",
            lambda trace: other.evaluator(trace) - self.evaluator(trace)
        )

    def __rmul__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{other.parend_expr()} * {self.parend_expr()}",
            lambda trace: other.evaluator(trace) * self.evaluator(trace)
        )

    def __rtruediv__(self, other):
        if isinstance(other, float):
            other = MathExpression.from_raw(other)
        return MathExpression(
            f"{other.parend_expr()} / {self.parend_expr()}",
            lambda trace: other.evaluator(trace) / self.evaluator(trace)
        )

    def derivative(self):
        def _derivative(trace):
            val = self.evaluator(trace)
            if isinstance(val, MathExpression):
                return val.derivative()
            elif isinstance(val, Signal):
                return trace[self.expr + "'"]
            else:
                raise ValueError(f"Cannot take derivative of {val}")
        return MathExpression(
            self.expr + "'", _derivative
        )


def proposition_node(fn):
    """Decorator for creating a proposition node class from a function-style definition."""
    properties = inspect.signature(fn).parameters

    if "lhs" in properties and "rhs" in properties:  # TODO: currently very ad-hoc
        has_math_nodes = True
    else:
        has_math_nodes = False

    @functools.wraps(fn)
    def to_evaluation_tree(self):
        kwargs = {
            prop.name: getattr(self, prop.name, prop.default)
            for prop in properties.values()
            if prop.name != "children"
        }
        if "children" in properties:
            children = map(lambda x: x.to_evaluation_tree(), self.children)
            return fn(*children, **kwargs)
        else:
            return fn(**kwargs)

    return type(
        fn.__name__,
        (Proposition,),
        {
            "to_evaluation_tree": to_evaluation_tree,
            "_prop_names": list(properties.keys()),
            "has_math_nodes": has_math_nodes
        }
    )

def augment_trace(
    proposition: Proposition,
    trace: Dict[str, Any]
) -> Dict[str, Any]:
    """Returns a copy of the trace with additonal entries for all math-expressions
    required for the evaluation of the proposition, i.e., the Predicate expressions in the `proposition.evalution_tree()`."""
    _trace = trace.copy()
    math_nodes = proposition.math_nodes

    # Handling PredicateCall
    # TODO: this is a hack, we should not need to do this

    for n in proposition.predicate_call_nodes:
        args, entity = n.context.resolve(n.symbol)

        if args != [e.to_key() for e in n.inputs]:
            new_tree = deepcopy(entity)
            assignments = dict(zip(args, n.inputs))
            new_tree.substitute_variables(assignments)
            _trace = augment_trace(new_tree, _trace)
        else:
            _trace = augment_trace(entity, _trace)

    for node in math_nodes:
        if node.to_key() in _trace:
            continue
        _trace[node.to_key()] = node.evaluator(_trace)
    return _trace
