#include "bindings.hpp"
#include "signal_tl/fmt.hpp"
#include "signal_tl/signal.hpp"

using namespace signal_tl;

void init_signal_module(py::module& parent) {
  using namespace signal;

  auto m = parent.def_submodule("signal", "A general class of signals (PWL, etc.)");
  py::bind_vector<std::vector<double>>(m, "DoubleVector", py::buffer_protocol());
  py::implicitly_convertible<py::list, std::vector<double>>();
  py::implicitly_convertible<py::array, std::vector<double>>();

  py::bind_vector<std::vector<Sample>>(m, "SampleList");
  py::bind_map<Trace>(m, "Trace").def(py::init<const Trace&>(), "other"_a);

  py::class_<Sample>(m, "Sample")
      .def(py::init())
      .def_readonly("time", &Sample::time)
      .def_readonly("value", &Sample::value)
      .def_readonly("derivative", &Sample::value)
      .def(py::self < py::self)
      .def(py::self > py::self)
      .def(py::self >= py::self)
      .def(py::self <= py::self)
      .def("__repr__", [](const Sample& e) { return fmt::format("{}", e); });

  py::class_<Signal, std::shared_ptr<Signal>>(m, "Signal")
      .def(py::init<>())
      .def(py::init<const Signal&>(), "other"_a)
      .def(py::init<const std::vector<Sample>&>())
      .def(
          py::init<const std::vector<double>&, const std::vector<double>&>(),
          "points"_a,
          "times"_a)
      .def_property_readonly("begin_time", &Signal::begin_time)
      .def_property_readonly("end_time", &Signal::end_time)
      .def_property_readonly("times", &Signal::times)
      .def_property_readonly("values", &Signal::values)
      .def("simplify", &Signal::simplify)
      .def("resize", &Signal::resize, "start"_a, "end"_a, "fill"_a)
      .def("shift", &Signal::shift, "dt"_a)
      .def("__repr__", [](const Signal& e) { return fmt::format("{}", e); })
      .def(
          "__iter__",
          [](const Signal& s) { return py::make_iterator(s.begin(), s.end()); },
          py::keep_alive<0, 1>())
      .def(
          "__getitem__",
          [](const SignalPtr& s, size_t i) { return s->at_idx(i).value; })
      .def("__len__", &Signal::size)
      .def("at", [](const SignalPtr& s, double t) { return s->at(t).value; })
      .def("__add__", [](const Signal& s1, const Signal& s2) { return s1 + s2; })
      .def("__sub__", [](const Signal& s1, const Signal& s2) { return s1 - s2; })
      .def("__mul__", [](const Signal& s1, const Signal& s2) { return s1 * s2; })
      .def("__truediv__", [](const Signal& s1, const Signal& s2) { return s1 / s2; })
      .def("__add__", [](const Signal& s, const double c) { return s + c; })
      .def("__sub__", [](const Signal& s, const double c) { return s - c; })
      .def("__mul__", [](const Signal& s, const double c) { return s * c; })
      .def("__truediv__", [](const Signal& s, const double c) { return s / c; })
      .def("__radd__", [](const Signal& s, const double c) { return c + s; })
      .def("__rsub__", [](const Signal& s, const double c) { return c - s; })
      .def("__rmul__", [](const Signal& s, const double c) { return c * s; })
      .def("__rtruediv__", [](const Signal& s, const double c) { return c / s; })

      ;

  m.def("synchronize", &synchronize, "x"_a, "y"_a);
}
