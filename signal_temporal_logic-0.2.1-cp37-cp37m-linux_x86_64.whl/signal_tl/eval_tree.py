from signal_tl._cext import (Always, And, Const, Eventually, Not, Or,
                             Predicate, Until, AvAlways, AvEventually, Area)

F = Eventually
G = Always
U = Until
AvF = AvEventually
AvG = AvAlways

TOP = Const(value=True)
BOT = Const(value=False)
