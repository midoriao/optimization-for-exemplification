from antlr4 import InputStream, CommonTokenStream

from signal_tl.ast_tool import MathExpression

from .stl_ast_visitor import StlAstTransformer
from .generated.StlLexer import StlLexer
from .generated.StlParser import StlParser
from signal_tl.ast import Proposition, augment_trace, Context
from signal_tl._cext.semantics import compute_robustness


def get_stl_ast(text: str, context = None) -> Proposition:
    input_stream = InputStream(text)
    lexer = StlLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = StlParser(stream)
    tree = parser.parse_stl()
    ast = StlAstTransformer(context).visit(tree)
    if ast is None:
        raise ValueError("Failed to parse STL formula : " + text)
    return ast

def parse_math(text: str, context = None) -> MathExpression:
    input_stream = InputStream(text)
    lexer = StlLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = StlParser(stream)
    tree = parser.parse_math_expression()
    math = StlAstTransformer(context).visit(tree)
    if math is None:
        raise ValueError("Failed to parse math expression: " + text)
    elif not isinstance(math, MathExpression):
        raise ValueError(f"Parse result {math} was not a math expression")
    return math

def eval_robustness(text: str, trace, context = None):
    ast = get_stl_ast(text, context)
    evaluation_tree = ast.to_evaluation_tree()
    trace = augment_trace(ast, trace)
    return compute_robustness(evaluation_tree, trace)

class SpecLoader:
    def __init__(self) -> None:
        self.context = Context()

    def def_function(self, symbol, args, text):
        math = parse_math(text, self.context)
        self.context.update(symbol, args=args, entity=math)
        return self

    def def_predicate(self, symbol, args, text):
        ast = get_stl_ast(text, self.context)
        self.context.update(symbol, args=args, entity=ast)
        return self

    def eval_robustness(self, text, trace):
        return eval_robustness(text, trace, self.context)

