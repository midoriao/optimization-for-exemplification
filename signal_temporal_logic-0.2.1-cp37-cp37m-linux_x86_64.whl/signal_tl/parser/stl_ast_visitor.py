from .generated.StlParserVisitor import StlParserVisitor
from .generated.StlParser import StlParser
from typing import Optional
import signal_tl.ast as ast


class StlAstTransformer(StlParserVisitor):

    def __init__(self, context: Optional[ast.Context] = None):
        self.defaultContext = ast.Context() if context is None else context
        super().__init__()

    def getContext(self):
        return self.defaultContext

    # Visit a parse tree produced by StlParser#AtomPropLt.
    def visitAtomPropGt(self, ctx:StlParser.AtomPropLtContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))
        return ast.Gt(lhs=lhs, rhs=rhs)

    # Visit a parse tree produced by StlParser#AtomPropGt.
    def visitAtomPropLt(self, ctx:StlParser.AtomPropGtContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))
        return ast.Lt(lhs=lhs, rhs=rhs)

    def aggregateResult(self, aggregate, nextResult):
        if nextResult is None:
            return aggregate
        return nextResult

    # Visit a parse tree produced by StlParser#PropImplies.
    def visitPropImplies(self, ctx:StlParser.PropImpliesContext):
        lhs = self.visit(ctx.proposition(0))
        rhs = self.visit(ctx.proposition(1))
        return ast.Implies([lhs, rhs])

    # Visit a parse tree produced by StlParser#PropPredicate.
    def visitPropPredicate(self, ctx:StlParser.PropPredicateContext):
        return ast.PredicateCall(
            symbol=ctx.predicate_symbol().getText(),
            inputs=[self.visit(ctx_me) for ctx_me in ctx.math_expression()],
            context=self.getContext()
        )

    # Visit a parse tree produced by StlParser#PropUntil.
    def visitPropUntil(self, ctx:StlParser.PropUntilContext):
        lhs = self.visit(ctx.proposition(0))
        rhs = self.visit(ctx.proposition(1))
        if ctx.interval() is None:
            interval = None
        else:
            interval = self.visit(ctx.interval())
        return ast.Until(lhs, rhs, interval=interval)

    # Visit a parse tree produced by StlParser#PropOr.
    def visitPropOr(self, ctx:StlParser.PropOrContext):
        lhs = self.visit(ctx.proposition(0))
        rhs = self.visit(ctx.proposition(1))
        return ast.Or(lhs, rhs)

    # Visit a parse tree produced by StlParser#PropNot.
    def visitPropNot(self, ctx:StlParser.PropNotContext):
        return ast.Not(self.visit(ctx.proposition()))

    # Visit a parse tree produced by StlParser#PropEventually.
    def visitPropEventually(self, ctx:StlParser.PropEventuallyContext):
        phi = self.visit(ctx.proposition())
        if ctx.interval() is None:
            interval = None
        else:
            interval = self.visit(ctx.interval())
        return ast.Eventually(phi, interval=interval)

    # Visit a parse tree produced by StlParser#PropAlways.
    def visitPropAlways(self, ctx:StlParser.PropAlwaysContext):
        phi = self.visit(ctx.proposition())
        if ctx.interval() is None:
            interval = None
        else:
            interval = self.visit(ctx.interval())
        return ast.Always(phi, interval=interval)


    # Visit a parse tree produced by StlParser#PropAnd.
    def visitPropAnd(self, ctx:StlParser.PropAndContext):
        lhs = self.visit(ctx.proposition(0))
        rhs = self.visit(ctx.proposition(1))
        return ast.And(lhs, rhs)


    # Visit a parse tree produced by StlParser#AtomPropTrue.
    def visitAtomPropTrue(self, ctx:StlParser.AtomPropTrueContext):
        return ast.TOP


    # Visit a parse tree produced by StlParser#AtomPropFalse.
    def visitAtomPropFalse(self, ctx:StlParser.AtomPropFalseContext):
        return ast.BOT


    # Visit a parse tree produced by StlParser#AtomPropEq.
    def visitAtomPropEq(self, ctx:StlParser.AtomPropEqContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))
        return ast.Eq(lhs=lhs, rhs=rhs)

    # Visit a parse tree produced by StlParser#AtomPropNeq.
    def visitAtomPropNeq(self, ctx:StlParser.AtomPropNeqContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))
        return ast.Not(ast.Eq(lhs=lhs, rhs=rhs))


    # Visit a parse tree produced by StlParser#interval.
    def visitInterval(self, ctx:StlParser.IntervalContext):
        return (self.visit(ctx.lb).value, self.visit(ctx.ub).value)

    # Visit a parse tree produced by StlParser#MathExpFunction.
    def visitMathExpFunction(self, ctx:StlParser.MathExpFunctionContext):
        return ast.FuncApp(
            symbol=ctx.function_symbol().getText(),
            inputs=[self.visit(ctx_me) for ctx_me in ctx.math_expression()],
            context=self.getContext()
        )

    # Visit a parse tree produced by StlParser#MathExpMultDiv.
    def visitMathExpMultDiv(self, ctx:StlParser.MathExpMultDivContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))

        if ctx.MULTIPLY() is not None:
            return lhs * rhs
        else:
            return lhs / rhs


    # Visit a parse tree produced by StlParser#MathExpPlusMinus.
    def visitMathExpPlusMinus(self, ctx:StlParser.MathExpPlusMinusContext):
        lhs = self.visit(ctx.math_expression(0))
        rhs = self.visit(ctx.math_expression(1))

        if ctx.PLUS() is not None:
            return lhs + rhs
        else:
            return lhs - rhs


    # Visit a parse tree produced by StlParser#MathExpSign.
    def visitMathExpSign(self, ctx:StlParser.MathExpSignContext):
        if ctx.sign().MINUS() is not None:
            return -self.visit(ctx.math_expression())
        else:
            return self.visit(ctx.math_expression())


    # Visit a parse tree produced by StlParser#ConstantExpPlusMinus.
    def visitConstantExpPlusMinus(self, ctx:StlParser.ConstantExpPlusMinusContext):
        lhs = self.visit(ctx.constant_expression(0))
        rhs = self.visit(ctx.constant_expression(1))

        if ctx.PLUS() is not None:
            return lhs + rhs
        else:
            return lhs - rhs


    # Visit a parse tree produced by StlParser#ConstantExpMultDiv.
    def visitConstantExpMultDiv(self, ctx:StlParser.ConstantExpMultDivContext):
        lhs = self.visit(ctx.constant_expression(0))
        rhs = self.visit(ctx.constant_expression(1))

        if ctx.MULTIPLY() is not None:
            return lhs * rhs
        else:
            return lhs / rhs


    # Visit a parse tree produced by StlParser#ConstantExpSign.
    def visitConstantExpSign(self, ctx:StlParser.ConstantExpSignContext):
        if ctx.sign().MINUS() is not None:
            return -self.visit(ctx.constant_expression())
        else:
            return self.visit(ctx.constant_expression())


    # Visit a parse tree produced by StlParser#numeric_literal.
    def visitNumeric_literal(self, ctx:StlParser.Numeric_literalContext):
        return ast.Value(float(ctx.getText()))


    # Visit a parse tree produced by StlParser#constant_symbol.
    def visitConstant_symbol(self, ctx:StlParser.Constant_symbolContext):
        raise NotImplementedError("Constant_symbol not implemented")


    # Visit a parse tree produced by StlParser#derivative.
    def visitDerivative(self, ctx:StlParser.DerivativeContext):
        order = len(ctx.PRIME())
        var = self.visit(ctx.variable_symbol())
        for _ in range(order):
            var = var.derivative()
        return var


    # Visit a parse tree produced by StlParser#variable_symbol.
    def visitVariable_symbol(self, ctx:StlParser.Variable_symbolContext):
        return ast.Var(ctx.getText())


    # Visit a parse tree produced by StlParser#function_symbol.
    def visitFunction_symbol(self, ctx:StlParser.Function_symbolContext):
        raise NotImplementedError("Function_symbol not implemented")
