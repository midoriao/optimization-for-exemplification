# Generated from StlParser.g4 by ANTLR 4.7.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .StlParser import StlParser
else:
    from StlParser import StlParser

# This class defines a complete generic visitor for a parse tree produced by StlParser.

class StlParserVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by StlParser#parse_stl.
    def visitParse_stl(self, ctx:StlParser.Parse_stlContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropAtomic.
    def visitPropAtomic(self, ctx:StlParser.PropAtomicContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropImplies.
    def visitPropImplies(self, ctx:StlParser.PropImpliesContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropPredicate.
    def visitPropPredicate(self, ctx:StlParser.PropPredicateContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropParen.
    def visitPropParen(self, ctx:StlParser.PropParenContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropUntil.
    def visitPropUntil(self, ctx:StlParser.PropUntilContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropOr.
    def visitPropOr(self, ctx:StlParser.PropOrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropNot.
    def visitPropNot(self, ctx:StlParser.PropNotContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropEventually.
    def visitPropEventually(self, ctx:StlParser.PropEventuallyContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropAlways.
    def visitPropAlways(self, ctx:StlParser.PropAlwaysContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#PropAnd.
    def visitPropAnd(self, ctx:StlParser.PropAndContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropTrue.
    def visitAtomPropTrue(self, ctx:StlParser.AtomPropTrueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropFalse.
    def visitAtomPropFalse(self, ctx:StlParser.AtomPropFalseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropLt.
    def visitAtomPropLt(self, ctx:StlParser.AtomPropLtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropGt.
    def visitAtomPropGt(self, ctx:StlParser.AtomPropGtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropEq.
    def visitAtomPropEq(self, ctx:StlParser.AtomPropEqContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#AtomPropNeq.
    def visitAtomPropNeq(self, ctx:StlParser.AtomPropNeqContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#UnaryOpNot.
    def visitUnaryOpNot(self, ctx:StlParser.UnaryOpNotContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#BinaryOpAnd.
    def visitBinaryOpAnd(self, ctx:StlParser.BinaryOpAndContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#BinaryOpOr.
    def visitBinaryOpOr(self, ctx:StlParser.BinaryOpOrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#BinaryOpImplies.
    def visitBinaryOpImplies(self, ctx:StlParser.BinaryOpImpliesContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#interval.
    def visitInterval(self, ctx:StlParser.IntervalContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#predicate_symbol.
    def visitPredicate_symbol(self, ctx:StlParser.Predicate_symbolContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#parse_math_expression.
    def visitParse_math_expression(self, ctx:StlParser.Parse_math_expressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpAtom.
    def visitMathExpAtom(self, ctx:StlParser.MathExpAtomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpFunction.
    def visitMathExpFunction(self, ctx:StlParser.MathExpFunctionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpMultDiv.
    def visitMathExpMultDiv(self, ctx:StlParser.MathExpMultDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpPlusMinus.
    def visitMathExpPlusMinus(self, ctx:StlParser.MathExpPlusMinusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpSign.
    def visitMathExpSign(self, ctx:StlParser.MathExpSignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#MathExpParen.
    def visitMathExpParen(self, ctx:StlParser.MathExpParenContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#math_atom.
    def visitMath_atom(self, ctx:StlParser.Math_atomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#ConstantExpParen.
    def visitConstantExpParen(self, ctx:StlParser.ConstantExpParenContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#ConstantExpPlusMinus.
    def visitConstantExpPlusMinus(self, ctx:StlParser.ConstantExpPlusMinusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#ConstantExpMultDiv.
    def visitConstantExpMultDiv(self, ctx:StlParser.ConstantExpMultDivContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#ConstantExpAtom.
    def visitConstantExpAtom(self, ctx:StlParser.ConstantExpAtomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#ConstantExpSign.
    def visitConstantExpSign(self, ctx:StlParser.ConstantExpSignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#sign.
    def visitSign(self, ctx:StlParser.SignContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#constant_atom.
    def visitConstant_atom(self, ctx:StlParser.Constant_atomContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#numeric_literal.
    def visitNumeric_literal(self, ctx:StlParser.Numeric_literalContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#constant_symbol.
    def visitConstant_symbol(self, ctx:StlParser.Constant_symbolContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#derivative.
    def visitDerivative(self, ctx:StlParser.DerivativeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#variable_symbol.
    def visitVariable_symbol(self, ctx:StlParser.Variable_symbolContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by StlParser#function_symbol.
    def visitFunction_symbol(self, ctx:StlParser.Function_symbolContext):
        return self.visitChildren(ctx)



del StlParser