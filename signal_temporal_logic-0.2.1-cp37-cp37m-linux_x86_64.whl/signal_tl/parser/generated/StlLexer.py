# Generated from StlLexer.g4 by ANTLR 4.7.2
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2%")
        buf.write("\u0134\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23")
        buf.write("\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30")
        buf.write("\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36")
        buf.write("\t\36\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%")
        buf.write("\4&\t&\4\'\t\'\4(\t(\3\2\3\2\3\3\3\3\3\4\3\4\3\5\3\5\3")
        buf.write("\6\3\6\3\7\3\7\3\b\3\b\3\t\3\t\3\n\3\n\3\13\3\13\3\f\3")
        buf.write("\f\3\r\3\r\3\r\3\16\3\16\3\17\3\17\3\17\3\20\3\20\3\20")
        buf.write("\3\21\3\21\3\21\3\22\3\22\3\22\3\22\3\22\3\22\3\22\5\22")
        buf.write("}\n\22\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\5")
        buf.write("\23\u0088\n\23\3\24\3\24\3\24\3\24\3\24\3\24\3\24\5\24")
        buf.write("\u0091\n\24\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3")
        buf.write("\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\5\25\u00a3\n\25")
        buf.write("\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26")
        buf.write("\3\26\5\26\u00b1\n\26\3\27\3\27\3\27\3\27\3\27\3\27\3")
        buf.write("\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\5\27\u00c2")
        buf.write("\n\27\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30")
        buf.write("\3\30\3\30\3\30\5\30\u00d1\n\30\3\31\3\31\3\31\3\31\3")
        buf.write("\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31\3\31")
        buf.write("\3\31\3\31\3\31\3\31\3\31\3\31\5\31\u00e8\n\31\3\32\3")
        buf.write("\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\5\32")
        buf.write("\u00f5\n\32\3\33\3\33\3\34\3\34\3\34\3\34\3\35\3\35\3")
        buf.write("\36\3\36\3\36\3\36\3\36\3\37\3\37\3\37\3\37\3\37\3 \3")
        buf.write(" \3 \7 \u010c\n \f \16 \u010f\13 \3!\3!\7!\u0113\n!\f")
        buf.write("!\16!\u0116\13!\3\"\3\"\3#\3#\5#\u011c\n#\3$\3$\3%\3%")
        buf.write("\3&\6&\u0123\n&\r&\16&\u0124\3&\3&\6&\u0129\n&\r&\16&")
        buf.write("\u012a\5&\u012d\n&\3\'\3\'\3\'\3\'\3(\3(\2\2)\3\3\5\4")
        buf.write("\7\5\t\6\13\7\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17")
        buf.write("\35\20\37\21!\22#\23%\24\'\25)\26+\27-\30/\31\61\32\63")
        buf.write("\33\65\34\67\359\36;\37= ?!A\"C\2E\2G#I\2K\2M$O%\3\2\7")
        buf.write("\3\2C\\\4\2C\\c|\5\2//\62;aa\3\2\62;\5\2\13\r\17\17\"")
        buf.write("\"\2\u014a\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2")
        buf.write("\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2")
        buf.write("\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2\2")
        buf.write("\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2\2\2#")
        buf.write("\3\2\2\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2")
        buf.write("\2-\3\2\2\2\2/\3\2\2\2\2\61\3\2\2\2\2\63\3\2\2\2\2\65")
        buf.write("\3\2\2\2\2\67\3\2\2\2\29\3\2\2\2\2;\3\2\2\2\2=\3\2\2\2")
        buf.write("\2?\3\2\2\2\2A\3\2\2\2\2G\3\2\2\2\2M\3\2\2\2\2O\3\2\2")
        buf.write("\2\3Q\3\2\2\2\5S\3\2\2\2\7U\3\2\2\2\tW\3\2\2\2\13Y\3\2")
        buf.write("\2\2\r[\3\2\2\2\17]\3\2\2\2\21_\3\2\2\2\23a\3\2\2\2\25")
        buf.write("c\3\2\2\2\27e\3\2\2\2\31g\3\2\2\2\33j\3\2\2\2\35l\3\2")
        buf.write("\2\2\37o\3\2\2\2!r\3\2\2\2#|\3\2\2\2%\u0087\3\2\2\2\'")
        buf.write("\u0090\3\2\2\2)\u00a2\3\2\2\2+\u00b0\3\2\2\2-\u00c1\3")
        buf.write("\2\2\2/\u00d0\3\2\2\2\61\u00e7\3\2\2\2\63\u00f4\3\2\2")
        buf.write("\2\65\u00f6\3\2\2\2\67\u00f8\3\2\2\29\u00fc\3\2\2\2;\u00fe")
        buf.write("\3\2\2\2=\u0103\3\2\2\2?\u0108\3\2\2\2A\u0110\3\2\2\2")
        buf.write("C\u0117\3\2\2\2E\u011b\3\2\2\2G\u011d\3\2\2\2I\u011f\3")
        buf.write("\2\2\2K\u0122\3\2\2\2M\u012e\3\2\2\2O\u0132\3\2\2\2QR")
        buf.write("\7*\2\2R\4\3\2\2\2ST\7+\2\2T\6\3\2\2\2UV\7]\2\2V\b\3\2")
        buf.write("\2\2WX\7_\2\2X\n\3\2\2\2YZ\7.\2\2Z\f\3\2\2\2[\\\7<\2\2")
        buf.write("\\\16\3\2\2\2]^\7-\2\2^\20\3\2\2\2_`\7/\2\2`\22\3\2\2")
        buf.write("\2ab\7,\2\2b\24\3\2\2\2cd\7\61\2\2d\26\3\2\2\2ef\7>\2")
        buf.write("\2f\30\3\2\2\2gh\7>\2\2hi\7?\2\2i\32\3\2\2\2jk\7@\2\2")
        buf.write("k\34\3\2\2\2lm\7@\2\2mn\7?\2\2n\36\3\2\2\2op\7?\2\2pq")
        buf.write("\7?\2\2q \3\2\2\2rs\7#\2\2st\7?\2\2t\"\3\2\2\2uv\7P\2")
        buf.write("\2vw\7Q\2\2w}\7V\2\2xy\7p\2\2yz\7q\2\2z}\7v\2\2{}\7\u0080")
        buf.write("\2\2|u\3\2\2\2|x\3\2\2\2|{\3\2\2\2}$\3\2\2\2~\177\7C\2")
        buf.write("\2\177\u0080\7P\2\2\u0080\u0088\7F\2\2\u0081\u0082\7c")
        buf.write("\2\2\u0082\u0083\7p\2\2\u0083\u0088\7f\2\2\u0084\u0085")
        buf.write("\7\61\2\2\u0085\u0088\7^\2\2\u0086\u0088\7(\2\2\u0087")
        buf.write("~\3\2\2\2\u0087\u0081\3\2\2\2\u0087\u0084\3\2\2\2\u0087")
        buf.write("\u0086\3\2\2\2\u0088&\3\2\2\2\u0089\u008a\7Q\2\2\u008a")
        buf.write("\u0091\7T\2\2\u008b\u008c\7q\2\2\u008c\u0091\7t\2\2\u008d")
        buf.write("\u008e\7^\2\2\u008e\u0091\7\61\2\2\u008f\u0091\7~\2\2")
        buf.write("\u0090\u0089\3\2\2\2\u0090\u008b\3\2\2\2\u0090\u008d\3")
        buf.write("\2\2\2\u0090\u008f\3\2\2\2\u0091(\3\2\2\2\u0092\u0093")
        buf.write("\7K\2\2\u0093\u0094\7O\2\2\u0094\u0095\7R\2\2\u0095\u0096")
        buf.write("\7N\2\2\u0096\u0097\7K\2\2\u0097\u0098\7G\2\2\u0098\u00a3")
        buf.write("\7U\2\2\u0099\u009a\7k\2\2\u009a\u009b\7o\2\2\u009b\u009c")
        buf.write("\7r\2\2\u009c\u009d\7n\2\2\u009d\u009e\7k\2\2\u009e\u009f")
        buf.write("\7g\2\2\u009f\u00a3\7u\2\2\u00a0\u00a1\7?\2\2\u00a1\u00a3")
        buf.write("\7@\2\2\u00a2\u0092\3\2\2\2\u00a2\u0099\3\2\2\2\u00a2")
        buf.write("\u00a0\3\2\2\2\u00a3*\3\2\2\2\u00a4\u00a5\7V\2\2\u00a5")
        buf.write("\u00a6\7T\2\2\u00a6\u00a7\7W\2\2\u00a7\u00b1\7G\2\2\u00a8")
        buf.write("\u00a9\7V\2\2\u00a9\u00aa\7t\2\2\u00aa\u00ab\7w\2\2\u00ab")
        buf.write("\u00b1\7g\2\2\u00ac\u00ad\7v\2\2\u00ad\u00ae\7t\2\2\u00ae")
        buf.write("\u00af\7w\2\2\u00af\u00b1\7g\2\2\u00b0\u00a4\3\2\2\2\u00b0")
        buf.write("\u00a8\3\2\2\2\u00b0\u00ac\3\2\2\2\u00b1,\3\2\2\2\u00b2")
        buf.write("\u00b3\7H\2\2\u00b3\u00b4\7C\2\2\u00b4\u00b5\7N\2\2\u00b5")
        buf.write("\u00b6\7U\2\2\u00b6\u00c2\7G\2\2\u00b7\u00b8\7H\2\2\u00b8")
        buf.write("\u00b9\7c\2\2\u00b9\u00ba\7n\2\2\u00ba\u00bb\7u\2\2\u00bb")
        buf.write("\u00c2\7g\2\2\u00bc\u00bd\7h\2\2\u00bd\u00be\7c\2\2\u00be")
        buf.write("\u00bf\7n\2\2\u00bf\u00c0\7u\2\2\u00c0\u00c2\7g\2\2\u00c1")
        buf.write("\u00b2\3\2\2\2\u00c1\u00b7\3\2\2\2\u00c1\u00bc\3\2\2\2")
        buf.write("\u00c2.\3\2\2\2\u00c3\u00c4\7C\2\2\u00c4\u00c5\7N\2\2")
        buf.write("\u00c5\u00c6\7Y\2\2\u00c6\u00c7\7C\2\2\u00c7\u00c8\7[")
        buf.write("\2\2\u00c8\u00d1\7U\2\2\u00c9\u00ca\7c\2\2\u00ca\u00cb")
        buf.write("\7n\2\2\u00cb\u00cc\7y\2\2\u00cc\u00cd\7c\2\2\u00cd\u00ce")
        buf.write("\7{\2\2\u00ce\u00d1\7u\2\2\u00cf\u00d1\7I\2\2\u00d0\u00c3")
        buf.write("\3\2\2\2\u00d0\u00c9\3\2\2\2\u00d0\u00cf\3\2\2\2\u00d1")
        buf.write("\60\3\2\2\2\u00d2\u00d3\7G\2\2\u00d3\u00d4\7X\2\2\u00d4")
        buf.write("\u00d5\7G\2\2\u00d5\u00d6\7P\2\2\u00d6\u00d7\7V\2\2\u00d7")
        buf.write("\u00d8\7W\2\2\u00d8\u00d9\7C\2\2\u00d9\u00da\7N\2\2\u00da")
        buf.write("\u00db\7N\2\2\u00db\u00e8\7[\2\2\u00dc\u00dd\7g\2\2\u00dd")
        buf.write("\u00de\7x\2\2\u00de\u00df\7g\2\2\u00df\u00e0\7p\2\2\u00e0")
        buf.write("\u00e1\7v\2\2\u00e1\u00e2\7w\2\2\u00e2\u00e3\7c\2\2\u00e3")
        buf.write("\u00e4\7n\2\2\u00e4\u00e5\7n\2\2\u00e5\u00e8\7{\2\2\u00e6")
        buf.write("\u00e8\7H\2\2\u00e7\u00d2\3\2\2\2\u00e7\u00dc\3\2\2\2")
        buf.write("\u00e7\u00e6\3\2\2\2\u00e8\62\3\2\2\2\u00e9\u00ea\7W\2")
        buf.write("\2\u00ea\u00eb\7P\2\2\u00eb\u00ec\7V\2\2\u00ec\u00ed\7")
        buf.write("K\2\2\u00ed\u00f5\7N\2\2\u00ee\u00ef\7w\2\2\u00ef\u00f0")
        buf.write("\7p\2\2\u00f0\u00f1\7v\2\2\u00f1\u00f2\7k\2\2\u00f2\u00f5")
        buf.write("\7n\2\2\u00f3\u00f5\7W\2\2\u00f4\u00e9\3\2\2\2\u00f4\u00ee")
        buf.write("\3\2\2\2\u00f4\u00f3\3\2\2\2\u00f5\64\3\2\2\2\u00f6\u00f7")
        buf.write("\7)\2\2\u00f7\66\3\2\2\2\u00f8\u00f9\7f\2\2\u00f9\u00fa")
        buf.write("\7g\2\2\u00fa\u00fb\7h\2\2\u00fb8\3\2\2\2\u00fc\u00fd")
        buf.write("\7?\2\2\u00fd:\3\2\2\2\u00fe\u00ff\7T\2\2\u00ff\u0100")
        buf.write("\7g\2\2\u0100\u0101\7c\2\2\u0101\u0102\7n\2\2\u0102<\3")
        buf.write("\2\2\2\u0103\u0104\7D\2\2\u0104\u0105\7q\2\2\u0105\u0106")
        buf.write("\7q\2\2\u0106\u0107\7n\2\2\u0107>\3\2\2\2\u0108\u010d")
        buf.write("\t\2\2\2\u0109\u010c\t\2\2\2\u010a\u010c\5I%\2\u010b\u0109")
        buf.write("\3\2\2\2\u010b\u010a\3\2\2\2\u010c\u010f\3\2\2\2\u010d")
        buf.write("\u010b\3\2\2\2\u010d\u010e\3\2\2\2\u010e@\3\2\2\2\u010f")
        buf.write("\u010d\3\2\2\2\u0110\u0114\5C\"\2\u0111\u0113\5E#\2\u0112")
        buf.write("\u0111\3\2\2\2\u0113\u0116\3\2\2\2\u0114\u0112\3\2\2\2")
        buf.write("\u0114\u0115\3\2\2\2\u0115B\3\2\2\2\u0116\u0114\3\2\2")
        buf.write("\2\u0117\u0118\t\3\2\2\u0118D\3\2\2\2\u0119\u011c\5C\"")
        buf.write("\2\u011a\u011c\t\4\2\2\u011b\u0119\3\2\2\2\u011b\u011a")
        buf.write("\3\2\2\2\u011cF\3\2\2\2\u011d\u011e\5K&\2\u011eH\3\2\2")
        buf.write("\2\u011f\u0120\t\5\2\2\u0120J\3\2\2\2\u0121\u0123\5I%")
        buf.write("\2\u0122\u0121\3\2\2\2\u0123\u0124\3\2\2\2\u0124\u0122")
        buf.write("\3\2\2\2\u0124\u0125\3\2\2\2\u0125\u012c\3\2\2\2\u0126")
        buf.write("\u0128\7\60\2\2\u0127\u0129\5I%\2\u0128\u0127\3\2\2\2")
        buf.write("\u0129\u012a\3\2\2\2\u012a\u0128\3\2\2\2\u012a\u012b\3")
        buf.write("\2\2\2\u012b\u012d\3\2\2\2\u012c\u0126\3\2\2\2\u012c\u012d")
        buf.write("\3\2\2\2\u012dL\3\2\2\2\u012e\u012f\t\6\2\2\u012f\u0130")
        buf.write("\3\2\2\2\u0130\u0131\b\'\2\2\u0131N\3\2\2\2\u0132\u0133")
        buf.write("\13\2\2\2\u0133P\3\2\2\2\23\2|\u0087\u0090\u00a2\u00b0")
        buf.write("\u00c1\u00d0\u00e7\u00f4\u010b\u010d\u0114\u011b\u0124")
        buf.write("\u012a\u012c\3\2\3\2")
        return buf.getvalue()


class StlLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    LPAREN = 1
    RPAREN = 2
    LBRACK = 3
    RBRACK = 4
    COMMA = 5
    COLON = 6
    PLUS = 7
    MINUS = 8
    MULTIPLY = 9
    DIVIDE = 10
    LT = 11
    LT_EQ = 12
    GT = 13
    GT_EQ = 14
    EQ = 15
    NOT_EQ = 16
    NOT = 17
    AND = 18
    OR = 19
    IMPLIES = 20
    TRUE = 21
    FALSE = 22
    ALWAYS = 23
    EVENTUALLY = 24
    UNTIL = 25
    PRIME = 26
    DEF = 27
    ASSIGN = 28
    REAL = 29
    BOOL = 30
    CONSTANT_IDENTIFIER = 31
    IDENTIFIER = 32
    NUMERIC_LITERAL = 33
    SPACES = 34
    UNEXPECTED_CHAR = 35

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "'('", "')'", "'['", "']'", "','", "':'", "'+'", "'-'", "'*'", 
            "'/'", "'<'", "'<='", "'>'", "'>='", "'=='", "'!='", "'''", 
            "'def'", "'='", "'Real'", "'Bool'" ]

    symbolicNames = [ "<INVALID>",
            "LPAREN", "RPAREN", "LBRACK", "RBRACK", "COMMA", "COLON", "PLUS", 
            "MINUS", "MULTIPLY", "DIVIDE", "LT", "LT_EQ", "GT", "GT_EQ", 
            "EQ", "NOT_EQ", "NOT", "AND", "OR", "IMPLIES", "TRUE", "FALSE", 
            "ALWAYS", "EVENTUALLY", "UNTIL", "PRIME", "DEF", "ASSIGN", "REAL", 
            "BOOL", "CONSTANT_IDENTIFIER", "IDENTIFIER", "NUMERIC_LITERAL", 
            "SPACES", "UNEXPECTED_CHAR" ]

    ruleNames = [ "LPAREN", "RPAREN", "LBRACK", "RBRACK", "COMMA", "COLON", 
                  "PLUS", "MINUS", "MULTIPLY", "DIVIDE", "LT", "LT_EQ", 
                  "GT", "GT_EQ", "EQ", "NOT_EQ", "NOT", "AND", "OR", "IMPLIES", 
                  "TRUE", "FALSE", "ALWAYS", "EVENTUALLY", "UNTIL", "PRIME", 
                  "DEF", "ASSIGN", "REAL", "BOOL", "CONSTANT_IDENTIFIER", 
                  "IDENTIFIER", "VALID_ID_START_CHAR", "VALID_ID_CHAR", 
                  "NUMERIC_LITERAL", "DIGIT", "NUMBER", "SPACES", "UNEXPECTED_CHAR" ]

    grammarFileName = "StlLexer.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


