# Generated from StlParser.g4 by ANTLR 4.7.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3%")
        buf.write("\u00d7\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\3\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3\62\n")
        buf.write("\3\3\3\3\3\3\3\5\3\67\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\7\3A\n\3\f\3\16\3D\13\3\3\3\3\3\5\3H\n\3\3\3\3\3")
        buf.write("\3\3\5\3M\n\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\7\3Y\n\3\f\3\16\3\\\13\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4p\n\4")
        buf.write("\3\5\3\5\3\6\3\6\3\6\5\6w\n\6\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write("\3\b\3\b\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3")
        buf.write("\n\3\n\3\n\3\n\3\n\3\n\7\n\u0092\n\n\f\n\16\n\u0095\13")
        buf.write("\n\5\n\u0097\n\n\3\n\3\n\5\n\u009b\n\n\3\n\3\n\3\n\3\n")
        buf.write("\3\n\3\n\7\n\u00a3\n\n\f\n\16\n\u00a6\13\n\3\13\3\13\3")
        buf.write("\13\5\13\u00ab\n\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3")
        buf.write("\f\5\f\u00b6\n\f\3\f\3\f\3\f\3\f\3\f\3\f\7\f\u00be\n\f")
        buf.write("\f\f\16\f\u00c1\13\f\3\r\3\r\3\16\3\16\5\16\u00c7\n\16")
        buf.write("\3\17\3\17\3\20\3\20\3\21\3\21\6\21\u00cf\n\21\r\21\16")
        buf.write("\21\u00d0\3\22\3\22\3\23\3\23\3\23\2\5\4\22\26\24\2\4")
        buf.write("\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$\2\6\3\2\r\16\3")
        buf.write("\2\17\20\3\2\13\f\3\2\t\n\2\u00e7\2&\3\2\2\2\4G\3\2\2")
        buf.write("\2\6o\3\2\2\2\bq\3\2\2\2\nv\3\2\2\2\fx\3\2\2\2\16~\3\2")
        buf.write("\2\2\20\u0080\3\2\2\2\22\u009a\3\2\2\2\24\u00aa\3\2\2")
        buf.write("\2\26\u00b5\3\2\2\2\30\u00c2\3\2\2\2\32\u00c6\3\2\2\2")
        buf.write("\34\u00c8\3\2\2\2\36\u00ca\3\2\2\2 \u00cc\3\2\2\2\"\u00d2")
        buf.write("\3\2\2\2$\u00d4\3\2\2\2&\'\5\4\3\2\'(\7\2\2\3(\3\3\2\2")
        buf.write("\2)*\b\3\1\2*H\5\6\4\2+,\7\3\2\2,-\5\4\3\2-.\7\4\2\2.")
        buf.write("H\3\2\2\2/\61\7\31\2\2\60\62\5\f\7\2\61\60\3\2\2\2\61")
        buf.write("\62\3\2\2\2\62\63\3\2\2\2\63H\5\4\3\n\64\66\7\32\2\2\65")
        buf.write("\67\5\f\7\2\66\65\3\2\2\2\66\67\3\2\2\2\678\3\2\2\28H")
        buf.write("\5\4\3\t9:\7\23\2\2:H\5\4\3\7;<\5\16\b\2<=\7\3\2\2=B\5")
        buf.write("\22\n\2>?\7\7\2\2?A\5\22\n\2@>\3\2\2\2AD\3\2\2\2B@\3\2")
        buf.write("\2\2BC\3\2\2\2CE\3\2\2\2DB\3\2\2\2EF\7\4\2\2FH\3\2\2\2")
        buf.write("G)\3\2\2\2G+\3\2\2\2G/\3\2\2\2G\64\3\2\2\2G9\3\2\2\2G")
        buf.write(";\3\2\2\2HZ\3\2\2\2IJ\f\b\2\2JL\7\33\2\2KM\5\f\7\2LK\3")
        buf.write("\2\2\2LM\3\2\2\2MN\3\2\2\2NY\5\4\3\tOP\f\6\2\2PQ\7\26")
        buf.write("\2\2QY\5\4\3\7RS\f\5\2\2ST\7\24\2\2TY\5\4\3\6UV\f\4\2")
        buf.write("\2VW\7\25\2\2WY\5\4\3\5XI\3\2\2\2XO\3\2\2\2XR\3\2\2\2")
        buf.write("XU\3\2\2\2Y\\\3\2\2\2ZX\3\2\2\2Z[\3\2\2\2[\5\3\2\2\2\\")
        buf.write("Z\3\2\2\2]p\7\27\2\2^p\7\30\2\2_`\5\22\n\2`a\t\2\2\2a")
        buf.write("b\5\22\n\2bp\3\2\2\2cd\5\22\n\2de\t\3\2\2ef\5\22\n\2f")
        buf.write("p\3\2\2\2gh\5\22\n\2hi\7\21\2\2ij\5\22\n\2jp\3\2\2\2k")
        buf.write("l\5\22\n\2lm\7\22\2\2mn\5\22\n\2np\3\2\2\2o]\3\2\2\2o")
        buf.write("^\3\2\2\2o_\3\2\2\2oc\3\2\2\2og\3\2\2\2ok\3\2\2\2p\7\3")
        buf.write("\2\2\2qr\7\23\2\2r\t\3\2\2\2sw\7\24\2\2tw\7\25\2\2uw\7")
        buf.write("\26\2\2vs\3\2\2\2vt\3\2\2\2vu\3\2\2\2w\13\3\2\2\2xy\7")
        buf.write("\5\2\2yz\5\26\f\2z{\7\7\2\2{|\5\26\f\2|}\7\6\2\2}\r\3")
        buf.write("\2\2\2~\177\7\"\2\2\177\17\3\2\2\2\u0080\u0081\5\22\n")
        buf.write("\2\u0081\u0082\7\2\2\3\u0082\21\3\2\2\2\u0083\u0084\b")
        buf.write("\n\1\2\u0084\u009b\5\24\13\2\u0085\u0086\7\3\2\2\u0086")
        buf.write("\u0087\5\22\n\2\u0087\u0088\7\4\2\2\u0088\u009b\3\2\2")
        buf.write("\2\u0089\u008a\5\30\r\2\u008a\u008b\5\22\n\6\u008b\u009b")
        buf.write("\3\2\2\2\u008c\u008d\5$\23\2\u008d\u0096\7\3\2\2\u008e")
        buf.write("\u0093\5\22\n\2\u008f\u0090\7\7\2\2\u0090\u0092\5\22\n")
        buf.write("\2\u0091\u008f\3\2\2\2\u0092\u0095\3\2\2\2\u0093\u0091")
        buf.write("\3\2\2\2\u0093\u0094\3\2\2\2\u0094\u0097\3\2\2\2\u0095")
        buf.write("\u0093\3\2\2\2\u0096\u008e\3\2\2\2\u0096\u0097\3\2\2\2")
        buf.write("\u0097\u0098\3\2\2\2\u0098\u0099\7\4\2\2\u0099\u009b\3")
        buf.write("\2\2\2\u009a\u0083\3\2\2\2\u009a\u0085\3\2\2\2\u009a\u0089")
        buf.write("\3\2\2\2\u009a\u008c\3\2\2\2\u009b\u00a4\3\2\2\2\u009c")
        buf.write("\u009d\f\5\2\2\u009d\u009e\t\4\2\2\u009e\u00a3\5\22\n")
        buf.write("\6\u009f\u00a0\f\4\2\2\u00a0\u00a1\t\5\2\2\u00a1\u00a3")
        buf.write("\5\22\n\5\u00a2\u009c\3\2\2\2\u00a2\u009f\3\2\2\2\u00a3")
        buf.write("\u00a6\3\2\2\2\u00a4\u00a2\3\2\2\2\u00a4\u00a5\3\2\2\2")
        buf.write("\u00a5\23\3\2\2\2\u00a6\u00a4\3\2\2\2\u00a7\u00ab\5\32")
        buf.write("\16\2\u00a8\u00ab\5 \21\2\u00a9\u00ab\5\"\22\2\u00aa\u00a7")
        buf.write("\3\2\2\2\u00aa\u00a8\3\2\2\2\u00aa\u00a9\3\2\2\2\u00ab")
        buf.write("\25\3\2\2\2\u00ac\u00ad\b\f\1\2\u00ad\u00b6\5\32\16\2")
        buf.write("\u00ae\u00af\7\3\2\2\u00af\u00b0\5\26\f\2\u00b0\u00b1")
        buf.write("\7\4\2\2\u00b1\u00b6\3\2\2\2\u00b2\u00b3\5\30\r\2\u00b3")
        buf.write("\u00b4\5\26\f\5\u00b4\u00b6\3\2\2\2\u00b5\u00ac\3\2\2")
        buf.write("\2\u00b5\u00ae\3\2\2\2\u00b5\u00b2\3\2\2\2\u00b6\u00bf")
        buf.write("\3\2\2\2\u00b7\u00b8\f\4\2\2\u00b8\u00b9\t\4\2\2\u00b9")
        buf.write("\u00be\5\26\f\5\u00ba\u00bb\f\3\2\2\u00bb\u00bc\t\5\2")
        buf.write("\2\u00bc\u00be\5\26\f\4\u00bd\u00b7\3\2\2\2\u00bd\u00ba")
        buf.write("\3\2\2\2\u00be\u00c1\3\2\2\2\u00bf\u00bd\3\2\2\2\u00bf")
        buf.write("\u00c0\3\2\2\2\u00c0\27\3\2\2\2\u00c1\u00bf\3\2\2\2\u00c2")
        buf.write("\u00c3\t\5\2\2\u00c3\31\3\2\2\2\u00c4\u00c7\5\34\17\2")
        buf.write("\u00c5\u00c7\5\36\20\2\u00c6\u00c4\3\2\2\2\u00c6\u00c5")
        buf.write("\3\2\2\2\u00c7\33\3\2\2\2\u00c8\u00c9\7#\2\2\u00c9\35")
        buf.write("\3\2\2\2\u00ca\u00cb\7!\2\2\u00cb\37\3\2\2\2\u00cc\u00ce")
        buf.write("\5\"\22\2\u00cd\u00cf\7\34\2\2\u00ce\u00cd\3\2\2\2\u00cf")
        buf.write("\u00d0\3\2\2\2\u00d0\u00ce\3\2\2\2\u00d0\u00d1\3\2\2\2")
        buf.write("\u00d1!\3\2\2\2\u00d2\u00d3\7\"\2\2\u00d3#\3\2\2\2\u00d4")
        buf.write("\u00d5\7\"\2\2\u00d5%\3\2\2\2\26\61\66BGLXZov\u0093\u0096")
        buf.write("\u009a\u00a2\u00a4\u00aa\u00b5\u00bd\u00bf\u00c6\u00d0")
        return buf.getvalue()


class StlParser ( Parser ):

    grammarFileName = "StlParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'['", "']'", "','", "':'", 
                     "'+'", "'-'", "'*'", "'/'", "'<'", "'<='", "'>'", "'>='", 
                     "'=='", "'!='", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'''", "'def'", "'='", "'Real'", 
                     "'Bool'" ]

    symbolicNames = [ "<INVALID>", "LPAREN", "RPAREN", "LBRACK", "RBRACK", 
                      "COMMA", "COLON", "PLUS", "MINUS", "MULTIPLY", "DIVIDE", 
                      "LT", "LT_EQ", "GT", "GT_EQ", "EQ", "NOT_EQ", "NOT", 
                      "AND", "OR", "IMPLIES", "TRUE", "FALSE", "ALWAYS", 
                      "EVENTUALLY", "UNTIL", "PRIME", "DEF", "ASSIGN", "REAL", 
                      "BOOL", "CONSTANT_IDENTIFIER", "IDENTIFIER", "NUMERIC_LITERAL", 
                      "SPACES", "UNEXPECTED_CHAR" ]

    RULE_parse_stl = 0
    RULE_proposition = 1
    RULE_atomic_proposition = 2
    RULE_unary_operator = 3
    RULE_binary_operator = 4
    RULE_interval = 5
    RULE_predicate_symbol = 6
    RULE_parse_math_expression = 7
    RULE_math_expression = 8
    RULE_math_atom = 9
    RULE_constant_expression = 10
    RULE_sign = 11
    RULE_constant_atom = 12
    RULE_numeric_literal = 13
    RULE_constant_symbol = 14
    RULE_derivative = 15
    RULE_variable_symbol = 16
    RULE_function_symbol = 17

    ruleNames =  [ "parse_stl", "proposition", "atomic_proposition", "unary_operator", 
                   "binary_operator", "interval", "predicate_symbol", "parse_math_expression", 
                   "math_expression", "math_atom", "constant_expression", 
                   "sign", "constant_atom", "numeric_literal", "constant_symbol", 
                   "derivative", "variable_symbol", "function_symbol" ]

    EOF = Token.EOF
    LPAREN=1
    RPAREN=2
    LBRACK=3
    RBRACK=4
    COMMA=5
    COLON=6
    PLUS=7
    MINUS=8
    MULTIPLY=9
    DIVIDE=10
    LT=11
    LT_EQ=12
    GT=13
    GT_EQ=14
    EQ=15
    NOT_EQ=16
    NOT=17
    AND=18
    OR=19
    IMPLIES=20
    TRUE=21
    FALSE=22
    ALWAYS=23
    EVENTUALLY=24
    UNTIL=25
    PRIME=26
    DEF=27
    ASSIGN=28
    REAL=29
    BOOL=30
    CONSTANT_IDENTIFIER=31
    IDENTIFIER=32
    NUMERIC_LITERAL=33
    SPACES=34
    UNEXPECTED_CHAR=35

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class Parse_stlContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def proposition(self):
            return self.getTypedRuleContext(StlParser.PropositionContext,0)


        def EOF(self):
            return self.getToken(StlParser.EOF, 0)

        def getRuleIndex(self):
            return StlParser.RULE_parse_stl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParse_stl" ):
                return visitor.visitParse_stl(self)
            else:
                return visitor.visitChildren(self)




    def parse_stl(self):

        localctx = StlParser.Parse_stlContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_parse_stl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 36
            self.proposition(0)
            self.state = 37
            self.match(StlParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PropositionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_proposition

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class PropAtomicContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def atomic_proposition(self):
            return self.getTypedRuleContext(StlParser.Atomic_propositionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropAtomic" ):
                return visitor.visitPropAtomic(self)
            else:
                return visitor.visitChildren(self)


    class PropImpliesContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def proposition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.PropositionContext)
            else:
                return self.getTypedRuleContext(StlParser.PropositionContext,i)

        def IMPLIES(self):
            return self.getToken(StlParser.IMPLIES, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropImplies" ):
                return visitor.visitPropImplies(self)
            else:
                return visitor.visitChildren(self)


    class PropPredicateContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def predicate_symbol(self):
            return self.getTypedRuleContext(StlParser.Predicate_symbolContext,0)

        def LPAREN(self):
            return self.getToken(StlParser.LPAREN, 0)
        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def RPAREN(self):
            return self.getToken(StlParser.RPAREN, 0)
        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(StlParser.COMMA)
            else:
                return self.getToken(StlParser.COMMA, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropPredicate" ):
                return visitor.visitPropPredicate(self)
            else:
                return visitor.visitChildren(self)


    class PropParenContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(StlParser.LPAREN, 0)
        def proposition(self):
            return self.getTypedRuleContext(StlParser.PropositionContext,0)

        def RPAREN(self):
            return self.getToken(StlParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropParen" ):
                return visitor.visitPropParen(self)
            else:
                return visitor.visitChildren(self)


    class PropUntilContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def proposition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.PropositionContext)
            else:
                return self.getTypedRuleContext(StlParser.PropositionContext,i)

        def UNTIL(self):
            return self.getToken(StlParser.UNTIL, 0)
        def interval(self):
            return self.getTypedRuleContext(StlParser.IntervalContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropUntil" ):
                return visitor.visitPropUntil(self)
            else:
                return visitor.visitChildren(self)


    class PropOrContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def proposition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.PropositionContext)
            else:
                return self.getTypedRuleContext(StlParser.PropositionContext,i)

        def OR(self):
            return self.getToken(StlParser.OR, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropOr" ):
                return visitor.visitPropOr(self)
            else:
                return visitor.visitChildren(self)


    class PropNotContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(StlParser.NOT, 0)
        def proposition(self):
            return self.getTypedRuleContext(StlParser.PropositionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropNot" ):
                return visitor.visitPropNot(self)
            else:
                return visitor.visitChildren(self)


    class PropEventuallyContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def EVENTUALLY(self):
            return self.getToken(StlParser.EVENTUALLY, 0)
        def proposition(self):
            return self.getTypedRuleContext(StlParser.PropositionContext,0)

        def interval(self):
            return self.getTypedRuleContext(StlParser.IntervalContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropEventually" ):
                return visitor.visitPropEventually(self)
            else:
                return visitor.visitChildren(self)


    class PropAlwaysContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ALWAYS(self):
            return self.getToken(StlParser.ALWAYS, 0)
        def proposition(self):
            return self.getTypedRuleContext(StlParser.PropositionContext,0)

        def interval(self):
            return self.getTypedRuleContext(StlParser.IntervalContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropAlways" ):
                return visitor.visitPropAlways(self)
            else:
                return visitor.visitChildren(self)


    class PropAndContext(PropositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.PropositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def proposition(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.PropositionContext)
            else:
                return self.getTypedRuleContext(StlParser.PropositionContext,i)

        def AND(self):
            return self.getToken(StlParser.AND, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPropAnd" ):
                return visitor.visitPropAnd(self)
            else:
                return visitor.visitChildren(self)



    def proposition(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = StlParser.PropositionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_proposition, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                localctx = StlParser.PropAtomicContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 40
                self.atomic_proposition()
                pass

            elif la_ == 2:
                localctx = StlParser.PropParenContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 41
                self.match(StlParser.LPAREN)
                self.state = 42
                self.proposition(0)
                self.state = 43
                self.match(StlParser.RPAREN)
                pass

            elif la_ == 3:
                localctx = StlParser.PropAlwaysContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 45
                self.match(StlParser.ALWAYS)
                self.state = 47
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==StlParser.LBRACK:
                    self.state = 46
                    self.interval()


                self.state = 49
                self.proposition(8)
                pass

            elif la_ == 4:
                localctx = StlParser.PropEventuallyContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 50
                self.match(StlParser.EVENTUALLY)
                self.state = 52
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==StlParser.LBRACK:
                    self.state = 51
                    self.interval()


                self.state = 54
                self.proposition(7)
                pass

            elif la_ == 5:
                localctx = StlParser.PropNotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 55
                self.match(StlParser.NOT)
                self.state = 56
                self.proposition(5)
                pass

            elif la_ == 6:
                localctx = StlParser.PropPredicateContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 57
                self.predicate_symbol()
                self.state = 58
                self.match(StlParser.LPAREN)
                self.state = 59
                self.math_expression(0)
                self.state = 64
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==StlParser.COMMA:
                    self.state = 60
                    self.match(StlParser.COMMA)
                    self.state = 61
                    self.math_expression(0)
                    self.state = 66
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 67
                self.match(StlParser.RPAREN)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 88
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,6,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 86
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
                    if la_ == 1:
                        localctx = StlParser.PropUntilContext(self, StlParser.PropositionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_proposition)
                        self.state = 71
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 72
                        self.match(StlParser.UNTIL)
                        self.state = 74
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==StlParser.LBRACK:
                            self.state = 73
                            self.interval()


                        self.state = 76
                        self.proposition(7)
                        pass

                    elif la_ == 2:
                        localctx = StlParser.PropImpliesContext(self, StlParser.PropositionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_proposition)
                        self.state = 77
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 78
                        self.match(StlParser.IMPLIES)
                        self.state = 79
                        self.proposition(5)
                        pass

                    elif la_ == 3:
                        localctx = StlParser.PropAndContext(self, StlParser.PropositionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_proposition)
                        self.state = 80
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 81
                        self.match(StlParser.AND)
                        self.state = 82
                        self.proposition(4)
                        pass

                    elif la_ == 4:
                        localctx = StlParser.PropOrContext(self, StlParser.PropositionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_proposition)
                        self.state = 83
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 84
                        self.match(StlParser.OR)
                        self.state = 85
                        self.proposition(3)
                        pass

             
                self.state = 90
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,6,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Atomic_propositionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_atomic_proposition

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class AtomPropEqContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def EQ(self):
            return self.getToken(StlParser.EQ, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropEq" ):
                return visitor.visitAtomPropEq(self)
            else:
                return visitor.visitChildren(self)


    class AtomPropGtContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def GT(self):
            return self.getToken(StlParser.GT, 0)
        def GT_EQ(self):
            return self.getToken(StlParser.GT_EQ, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropGt" ):
                return visitor.visitAtomPropGt(self)
            else:
                return visitor.visitChildren(self)


    class AtomPropTrueContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TRUE(self):
            return self.getToken(StlParser.TRUE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropTrue" ):
                return visitor.visitAtomPropTrue(self)
            else:
                return visitor.visitChildren(self)


    class AtomPropNeqContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def NOT_EQ(self):
            return self.getToken(StlParser.NOT_EQ, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropNeq" ):
                return visitor.visitAtomPropNeq(self)
            else:
                return visitor.visitChildren(self)


    class AtomPropFalseContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FALSE(self):
            return self.getToken(StlParser.FALSE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropFalse" ):
                return visitor.visitAtomPropFalse(self)
            else:
                return visitor.visitChildren(self)


    class AtomPropLtContext(Atomic_propositionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Atomic_propositionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def LT(self):
            return self.getToken(StlParser.LT, 0)
        def LT_EQ(self):
            return self.getToken(StlParser.LT_EQ, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtomPropLt" ):
                return visitor.visitAtomPropLt(self)
            else:
                return visitor.visitChildren(self)



    def atomic_proposition(self):

        localctx = StlParser.Atomic_propositionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_atomic_proposition)
        self._la = 0 # Token type
        try:
            self.state = 109
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                localctx = StlParser.AtomPropTrueContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 91
                self.match(StlParser.TRUE)
                pass

            elif la_ == 2:
                localctx = StlParser.AtomPropFalseContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 92
                self.match(StlParser.FALSE)
                pass

            elif la_ == 3:
                localctx = StlParser.AtomPropLtContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 93
                self.math_expression(0)
                self.state = 94
                _la = self._input.LA(1)
                if not(_la==StlParser.LT or _la==StlParser.LT_EQ):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 95
                self.math_expression(0)
                pass

            elif la_ == 4:
                localctx = StlParser.AtomPropGtContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 97
                self.math_expression(0)
                self.state = 98
                _la = self._input.LA(1)
                if not(_la==StlParser.GT or _la==StlParser.GT_EQ):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 99
                self.math_expression(0)
                pass

            elif la_ == 5:
                localctx = StlParser.AtomPropEqContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 101
                self.math_expression(0)
                self.state = 102
                self.match(StlParser.EQ)
                self.state = 103
                self.math_expression(0)
                pass

            elif la_ == 6:
                localctx = StlParser.AtomPropNeqContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 105
                self.math_expression(0)
                self.state = 106
                self.match(StlParser.NOT_EQ)
                self.state = 107
                self.math_expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Unary_operatorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_unary_operator

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UnaryOpNotContext(Unary_operatorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Unary_operatorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(StlParser.NOT, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryOpNot" ):
                return visitor.visitUnaryOpNot(self)
            else:
                return visitor.visitChildren(self)



    def unary_operator(self):

        localctx = StlParser.Unary_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_unary_operator)
        try:
            localctx = StlParser.UnaryOpNotContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 111
            self.match(StlParser.NOT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Binary_operatorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_binary_operator

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class BinaryOpOrContext(Binary_operatorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Binary_operatorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def OR(self):
            return self.getToken(StlParser.OR, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinaryOpOr" ):
                return visitor.visitBinaryOpOr(self)
            else:
                return visitor.visitChildren(self)


    class BinaryOpAndContext(Binary_operatorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Binary_operatorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def AND(self):
            return self.getToken(StlParser.AND, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinaryOpAnd" ):
                return visitor.visitBinaryOpAnd(self)
            else:
                return visitor.visitChildren(self)


    class BinaryOpImpliesContext(Binary_operatorContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Binary_operatorContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IMPLIES(self):
            return self.getToken(StlParser.IMPLIES, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBinaryOpImplies" ):
                return visitor.visitBinaryOpImplies(self)
            else:
                return visitor.visitChildren(self)



    def binary_operator(self):

        localctx = StlParser.Binary_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_binary_operator)
        try:
            self.state = 116
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [StlParser.AND]:
                localctx = StlParser.BinaryOpAndContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 113
                self.match(StlParser.AND)
                pass
            elif token in [StlParser.OR]:
                localctx = StlParser.BinaryOpOrContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 114
                self.match(StlParser.OR)
                pass
            elif token in [StlParser.IMPLIES]:
                localctx = StlParser.BinaryOpImpliesContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 115
                self.match(StlParser.IMPLIES)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IntervalContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self.lb = None # Constant_expressionContext
            self.ub = None # Constant_expressionContext

        def LBRACK(self):
            return self.getToken(StlParser.LBRACK, 0)

        def COMMA(self):
            return self.getToken(StlParser.COMMA, 0)

        def RBRACK(self):
            return self.getToken(StlParser.RBRACK, 0)

        def constant_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Constant_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Constant_expressionContext,i)


        def getRuleIndex(self):
            return StlParser.RULE_interval

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInterval" ):
                return visitor.visitInterval(self)
            else:
                return visitor.visitChildren(self)




    def interval(self):

        localctx = StlParser.IntervalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_interval)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 118
            self.match(StlParser.LBRACK)
            self.state = 119
            localctx.lb = self.constant_expression(0)
            self.state = 120
            self.match(StlParser.COMMA)
            self.state = 121
            localctx.ub = self.constant_expression(0)
            self.state = 122
            self.match(StlParser.RBRACK)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Predicate_symbolContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(StlParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return StlParser.RULE_predicate_symbol

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPredicate_symbol" ):
                return visitor.visitPredicate_symbol(self)
            else:
                return visitor.visitChildren(self)




    def predicate_symbol(self):

        localctx = StlParser.Predicate_symbolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_predicate_symbol)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.match(StlParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Parse_math_expressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def math_expression(self):
            return self.getTypedRuleContext(StlParser.Math_expressionContext,0)


        def EOF(self):
            return self.getToken(StlParser.EOF, 0)

        def getRuleIndex(self):
            return StlParser.RULE_parse_math_expression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParse_math_expression" ):
                return visitor.visitParse_math_expression(self)
            else:
                return visitor.visitChildren(self)




    def parse_math_expression(self):

        localctx = StlParser.Parse_math_expressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_parse_math_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.math_expression(0)
            self.state = 127
            self.match(StlParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Math_expressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_math_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class MathExpAtomContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_atom(self):
            return self.getTypedRuleContext(StlParser.Math_atomContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpAtom" ):
                return visitor.visitMathExpAtom(self)
            else:
                return visitor.visitChildren(self)


    class MathExpFunctionContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def function_symbol(self):
            return self.getTypedRuleContext(StlParser.Function_symbolContext,0)

        def LPAREN(self):
            return self.getToken(StlParser.LPAREN, 0)
        def RPAREN(self):
            return self.getToken(StlParser.RPAREN, 0)
        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(StlParser.COMMA)
            else:
                return self.getToken(StlParser.COMMA, i)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpFunction" ):
                return visitor.visitMathExpFunction(self)
            else:
                return visitor.visitChildren(self)


    class MathExpMultDivContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def MULTIPLY(self):
            return self.getToken(StlParser.MULTIPLY, 0)
        def DIVIDE(self):
            return self.getToken(StlParser.DIVIDE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpMultDiv" ):
                return visitor.visitMathExpMultDiv(self)
            else:
                return visitor.visitChildren(self)


    class MathExpPlusMinusContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def math_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Math_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Math_expressionContext,i)

        def PLUS(self):
            return self.getToken(StlParser.PLUS, 0)
        def MINUS(self):
            return self.getToken(StlParser.MINUS, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpPlusMinus" ):
                return visitor.visitMathExpPlusMinus(self)
            else:
                return visitor.visitChildren(self)


    class MathExpSignContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sign(self):
            return self.getTypedRuleContext(StlParser.SignContext,0)

        def math_expression(self):
            return self.getTypedRuleContext(StlParser.Math_expressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpSign" ):
                return visitor.visitMathExpSign(self)
            else:
                return visitor.visitChildren(self)


    class MathExpParenContext(Math_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Math_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(StlParser.LPAREN, 0)
        def math_expression(self):
            return self.getTypedRuleContext(StlParser.Math_expressionContext,0)

        def RPAREN(self):
            return self.getToken(StlParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMathExpParen" ):
                return visitor.visitMathExpParen(self)
            else:
                return visitor.visitChildren(self)



    def math_expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = StlParser.Math_expressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 16
        self.enterRecursionRule(localctx, 16, self.RULE_math_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 152
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                localctx = StlParser.MathExpAtomContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 130
                self.math_atom()
                pass

            elif la_ == 2:
                localctx = StlParser.MathExpParenContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 131
                self.match(StlParser.LPAREN)
                self.state = 132
                self.math_expression(0)
                self.state = 133
                self.match(StlParser.RPAREN)
                pass

            elif la_ == 3:
                localctx = StlParser.MathExpSignContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 135
                self.sign()
                self.state = 136
                self.math_expression(4)
                pass

            elif la_ == 4:
                localctx = StlParser.MathExpFunctionContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 138
                self.function_symbol()
                self.state = 139
                self.match(StlParser.LPAREN)
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << StlParser.LPAREN) | (1 << StlParser.PLUS) | (1 << StlParser.MINUS) | (1 << StlParser.CONSTANT_IDENTIFIER) | (1 << StlParser.IDENTIFIER) | (1 << StlParser.NUMERIC_LITERAL))) != 0):
                    self.state = 140
                    self.math_expression(0)
                    self.state = 145
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==StlParser.COMMA:
                        self.state = 141
                        self.match(StlParser.COMMA)
                        self.state = 142
                        self.math_expression(0)
                        self.state = 147
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 150
                self.match(StlParser.RPAREN)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 162
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,13,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 160
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                    if la_ == 1:
                        localctx = StlParser.MathExpMultDivContext(self, StlParser.Math_expressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_expression)
                        self.state = 154
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 155
                        _la = self._input.LA(1)
                        if not(_la==StlParser.MULTIPLY or _la==StlParser.DIVIDE):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 156
                        self.math_expression(4)
                        pass

                    elif la_ == 2:
                        localctx = StlParser.MathExpPlusMinusContext(self, StlParser.Math_expressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_expression)
                        self.state = 157
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 158
                        _la = self._input.LA(1)
                        if not(_la==StlParser.PLUS or _la==StlParser.MINUS):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 159
                        self.math_expression(3)
                        pass

             
                self.state = 164
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,13,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Math_atomContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def constant_atom(self):
            return self.getTypedRuleContext(StlParser.Constant_atomContext,0)


        def derivative(self):
            return self.getTypedRuleContext(StlParser.DerivativeContext,0)


        def variable_symbol(self):
            return self.getTypedRuleContext(StlParser.Variable_symbolContext,0)


        def getRuleIndex(self):
            return StlParser.RULE_math_atom

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMath_atom" ):
                return visitor.visitMath_atom(self)
            else:
                return visitor.visitChildren(self)




    def math_atom(self):

        localctx = StlParser.Math_atomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_math_atom)
        try:
            self.state = 168
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 165
                self.constant_atom()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 166
                self.derivative()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 167
                self.variable_symbol()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Constant_expressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return StlParser.RULE_constant_expression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ConstantExpParenContext(Constant_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Constant_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LPAREN(self):
            return self.getToken(StlParser.LPAREN, 0)
        def constant_expression(self):
            return self.getTypedRuleContext(StlParser.Constant_expressionContext,0)

        def RPAREN(self):
            return self.getToken(StlParser.RPAREN, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantExpParen" ):
                return visitor.visitConstantExpParen(self)
            else:
                return visitor.visitChildren(self)


    class ConstantExpPlusMinusContext(Constant_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Constant_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constant_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Constant_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Constant_expressionContext,i)

        def PLUS(self):
            return self.getToken(StlParser.PLUS, 0)
        def MINUS(self):
            return self.getToken(StlParser.MINUS, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantExpPlusMinus" ):
                return visitor.visitConstantExpPlusMinus(self)
            else:
                return visitor.visitChildren(self)


    class ConstantExpMultDivContext(Constant_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Constant_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constant_expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(StlParser.Constant_expressionContext)
            else:
                return self.getTypedRuleContext(StlParser.Constant_expressionContext,i)

        def MULTIPLY(self):
            return self.getToken(StlParser.MULTIPLY, 0)
        def DIVIDE(self):
            return self.getToken(StlParser.DIVIDE, 0)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantExpMultDiv" ):
                return visitor.visitConstantExpMultDiv(self)
            else:
                return visitor.visitChildren(self)


    class ConstantExpAtomContext(Constant_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Constant_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def constant_atom(self):
            return self.getTypedRuleContext(StlParser.Constant_atomContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantExpAtom" ):
                return visitor.visitConstantExpAtom(self)
            else:
                return visitor.visitChildren(self)


    class ConstantExpSignContext(Constant_expressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a StlParser.Constant_expressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def sign(self):
            return self.getTypedRuleContext(StlParser.SignContext,0)

        def constant_expression(self):
            return self.getTypedRuleContext(StlParser.Constant_expressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstantExpSign" ):
                return visitor.visitConstantExpSign(self)
            else:
                return visitor.visitChildren(self)



    def constant_expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = StlParser.Constant_expressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 20
        self.enterRecursionRule(localctx, 20, self.RULE_constant_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [StlParser.CONSTANT_IDENTIFIER, StlParser.NUMERIC_LITERAL]:
                localctx = StlParser.ConstantExpAtomContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 171
                self.constant_atom()
                pass
            elif token in [StlParser.LPAREN]:
                localctx = StlParser.ConstantExpParenContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 172
                self.match(StlParser.LPAREN)
                self.state = 173
                self.constant_expression(0)
                self.state = 174
                self.match(StlParser.RPAREN)
                pass
            elif token in [StlParser.PLUS, StlParser.MINUS]:
                localctx = StlParser.ConstantExpSignContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 176
                self.sign()
                self.state = 177
                self.constant_expression(3)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 189
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,17,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 187
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
                    if la_ == 1:
                        localctx = StlParser.ConstantExpMultDivContext(self, StlParser.Constant_expressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constant_expression)
                        self.state = 181
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 182
                        _la = self._input.LA(1)
                        if not(_la==StlParser.MULTIPLY or _la==StlParser.DIVIDE):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 183
                        self.constant_expression(3)
                        pass

                    elif la_ == 2:
                        localctx = StlParser.ConstantExpPlusMinusContext(self, StlParser.Constant_expressionContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_constant_expression)
                        self.state = 184
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 185
                        _la = self._input.LA(1)
                        if not(_la==StlParser.PLUS or _la==StlParser.MINUS):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 186
                        self.constant_expression(2)
                        pass

             
                self.state = 191
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,17,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class SignContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(StlParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(StlParser.MINUS, 0)

        def getRuleIndex(self):
            return StlParser.RULE_sign

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSign" ):
                return visitor.visitSign(self)
            else:
                return visitor.visitChildren(self)




    def sign(self):

        localctx = StlParser.SignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_sign)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 192
            _la = self._input.LA(1)
            if not(_la==StlParser.PLUS or _la==StlParser.MINUS):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Constant_atomContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def numeric_literal(self):
            return self.getTypedRuleContext(StlParser.Numeric_literalContext,0)


        def constant_symbol(self):
            return self.getTypedRuleContext(StlParser.Constant_symbolContext,0)


        def getRuleIndex(self):
            return StlParser.RULE_constant_atom

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant_atom" ):
                return visitor.visitConstant_atom(self)
            else:
                return visitor.visitChildren(self)




    def constant_atom(self):

        localctx = StlParser.Constant_atomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_constant_atom)
        try:
            self.state = 196
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [StlParser.NUMERIC_LITERAL]:
                self.enterOuterAlt(localctx, 1)
                self.state = 194
                self.numeric_literal()
                pass
            elif token in [StlParser.CONSTANT_IDENTIFIER]:
                self.enterOuterAlt(localctx, 2)
                self.state = 195
                self.constant_symbol()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Numeric_literalContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERIC_LITERAL(self):
            return self.getToken(StlParser.NUMERIC_LITERAL, 0)

        def getRuleIndex(self):
            return StlParser.RULE_numeric_literal

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNumeric_literal" ):
                return visitor.visitNumeric_literal(self)
            else:
                return visitor.visitChildren(self)




    def numeric_literal(self):

        localctx = StlParser.Numeric_literalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_numeric_literal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 198
            self.match(StlParser.NUMERIC_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Constant_symbolContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def CONSTANT_IDENTIFIER(self):
            return self.getToken(StlParser.CONSTANT_IDENTIFIER, 0)

        def getRuleIndex(self):
            return StlParser.RULE_constant_symbol

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant_symbol" ):
                return visitor.visitConstant_symbol(self)
            else:
                return visitor.visitChildren(self)




    def constant_symbol(self):

        localctx = StlParser.Constant_symbolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_constant_symbol)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 200
            self.match(StlParser.CONSTANT_IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DerivativeContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_symbol(self):
            return self.getTypedRuleContext(StlParser.Variable_symbolContext,0)


        def PRIME(self, i:int=None):
            if i is None:
                return self.getTokens(StlParser.PRIME)
            else:
                return self.getToken(StlParser.PRIME, i)

        def getRuleIndex(self):
            return StlParser.RULE_derivative

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDerivative" ):
                return visitor.visitDerivative(self)
            else:
                return visitor.visitChildren(self)




    def derivative(self):

        localctx = StlParser.DerivativeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_derivative)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self.variable_symbol()
            self.state = 204 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 203
                    self.match(StlParser.PRIME)

                else:
                    raise NoViableAltException(self)
                self.state = 206 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,19,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Variable_symbolContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(StlParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return StlParser.RULE_variable_symbol

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable_symbol" ):
                return visitor.visitVariable_symbol(self)
            else:
                return visitor.visitChildren(self)




    def variable_symbol(self):

        localctx = StlParser.Variable_symbolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_variable_symbol)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 208
            self.match(StlParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Function_symbolContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(StlParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return StlParser.RULE_function_symbol

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunction_symbol" ):
                return visitor.visitFunction_symbol(self)
            else:
                return visitor.visitChildren(self)




    def function_symbol(self):

        localctx = StlParser.Function_symbolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_function_symbol)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self.match(StlParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.proposition_sempred
        self._predicates[8] = self.math_expression_sempred
        self._predicates[10] = self.constant_expression_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def proposition_sempred(self, localctx:PropositionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 2)
         

    def math_expression_sempred(self, localctx:Math_expressionContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 2)
         

    def constant_expression_sempred(self, localctx:Constant_expressionContext, predIndex:int):
            if predIndex == 6:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 1)
         




