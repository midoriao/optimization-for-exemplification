from __future__ import annotations
import signal_tl.eval_tree as eval_tree

import functools

from typing import Tuple, Optional, List, Dict
from copy import deepcopy
from .ast_tool import Context, Proposition, MathExpression, proposition_node, augment_trace



@proposition_node
def Always(
    *children,
    interval: Optional[Tuple[float, float]] = None
):
    return eval_tree.Always(children[0], interval)

@proposition_node
def Eventually(
    *children,
    interval: Optional[Tuple[float, float]] = None
):
    return eval_tree.Eventually(children[0], interval)

@proposition_node
def Until(
    *children,
    interval: Optional[Tuple[float, float]] = None
):
    return eval_tree.Until(children[0], children[1], interval)

@proposition_node
def Not(
    *children
):
    return ~children[0]


@proposition_node
def Implies(
    *children
):
    return ~children[0] | children[1]

@proposition_node
def And(
    *children
):
    return functools.reduce(
        lambda x, y: x & y,
        children
    )

@proposition_node
def Or(
    *children
):
    return functools.reduce(
        lambda x, y: x | y,
        children
    )

@proposition_node
def PredicateCall(
    symbol: str,  inputs: List[MathExpression], context: Context
):
    args, entity = context.resolve(symbol)
    if args != [e.to_key() for e in inputs]:
        new_tree = deepcopy(entity)
        assignments = dict(zip(args, inputs))
        new_tree.substitute_variables(assignments)
        return new_tree.to_evaluation_tree()
    return entity.to_evaluation_tree()

@proposition_node
def Const(
    value: bool
):
    return eval_tree.Const(value)

@proposition_node
def Gt(
    lhs: MathExpression,
    rhs: MathExpression
):
    if lhs.is_constant and rhs.is_constant:
        return eval_tree.Const(lhs.value > rhs.value)
    elif lhs.is_constant:
        return lhs.value > eval_tree.Predicate(rhs.to_key())
    elif rhs.is_constant:
        return eval_tree.Predicate(lhs.to_key()) > rhs.value
    else:
        return eval_tree.Predicate(
            (lhs - rhs).to_key()
        ) > 0

@proposition_node
def Lt(
    lhs: MathExpression,
    rhs: MathExpression
):
    if lhs.is_constant and rhs.is_constant:
        return eval_tree.Const(lhs.value < rhs.value)
    elif lhs.is_constant:
        return lhs.value > eval_tree.Predicate(rhs.to_key())
    elif rhs.is_constant:
        return eval_tree.Predicate(lhs.to_key()) < rhs.value
    else:
        return eval_tree.Predicate(
            (lhs - rhs).to_key()
        ) < 0

@proposition_node
def Eq(
    lhs: MathExpression,
    rhs: MathExpression
):
    def eq(expr, value, epsilon: float = 1e-3):
        return (eval_tree.Predicate(expr.to_key()) < value + epsilon) & (eval_tree.Predicate(expr.to_key()) > value - epsilon)

    if lhs.is_constant and rhs.is_constant:
        return eval_tree.Const(lhs.value > rhs.value)
    elif lhs.is_constant:
        return eq(rhs, lhs.value)
    elif rhs.is_constant:
        return eq(lhs, rhs.value)
    else:
        return eq(lhs - rhs, 0)

def Var(name: str):
    return MathExpression.from_raw(name)

def Value(value: float):
    return MathExpression.from_raw(value)

def FuncApp(symbol: str,  inputs: List[MathExpression], context: Context):
    return MathExpression.from_function_application(symbol, inputs, context)


F = Eventually
G = Always
U = Until
# AvF = AvEventually
# AvG = AvAlways

TOP = Const(value=True)
BOT = Const(value=False)


__all__ = [
    "Always", "Eventually", "Until", "Not", "Implies", "And", "Or", "PredicateCall", "Const", "Gt", "Lt", "Eq", "F", "G", "U", "TOP", "BOT", "Var", "Value", "FuncApp", "Proposition", "augment_trace"
]
